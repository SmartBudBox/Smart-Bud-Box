<?php

class Core extends DB {
    public $box_id = FALSE;
    public $box = FALSE;
    public $settings = FALSE;
    
    function __construct() {
        parent::__construct();
        
        $this->get_box_id();
    }

    function get_box_id() {
        if (isset($_GET["box"])) {
            $this->box_id = $_GET["box"];
            setcookie("box", $this->box_id, time() + (86400 * 30), "/");
        } elseif (isset($_COOKIE["box"])) {
            $this->box_id = $_COOKIE["box"];
        } elseif (isset($Main -> boxes[0])) {
            $this->box_id = $Main -> boxes[0]["id"];
            setcookie("box", $box_id, time() + (86400 * 30), "/");
        } else {
            $this->box_id = 1;
        }
        
        
        $this->box = $this->get("boxes", array("id" => $this->box_id));

        
        return;
    }    
    
    function create_transmisson($from, $to, $command, $validity_from=false) {
        $command_json = json_encode($command);
       
       // check if transmission already exist 
       $data = array(
        "sender" => $from, 
        "recipient" => $to, 
        "data" => $command_json
       );
       
       if ($validity_from) {
         $data["validity_from"] = $validity_from;
       }
       
       $check = $this->get("_transmissions", $data);
       
       // if already exist return
       if (isset($check[0])) {
            return;   
       }
       
        // otherwise create data array for insert
        $data = array(
         "sender" => $from, 
         "recipient" => $to, 
         "data" => $command_json
        );
       
        // create message log and put validity_from into data array if isset
       if ($validity_from) {
         $data["validity_from"] = $validity_from;
         $command_json = $command_json . " @" . $validity_from;  
       } 
       else {
           $data["validity_from"] = $this->mysql_datetime();
       }
       
       //change!!!
       $this->create_message_log($command_json); 
       
       //submit to database
       $insert = $this->insert("_transmissions", $data);

       return $insert;
    }

    function create_message_log($message, $type="info") 
    {
        $data = array(
           "box" => $this->box["id"],
           "message" => $message,
           "type" => $type  
        );
       $this->insert("messages", $data);
    }
    
    function create_error($message) 
    {
        return;
    }
    
    function mysql_datetime($timestamp=false) {
        if ($timestamp) {
            $return = date('Y-m-d H:i:s', $timestamp);
        } else {
            $return = date('Y-m-d H:i:s');
        }
        return $return ;
    }
}

?>