-- phpMyAdmin SQL Dump
-- version 4.2.12deb2+deb8u2
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Erstellungszeit: 08. Nov 2017 um 22:22
-- Server Version: 10.0.30-MariaDB-0+deb8u2
-- PHP-Version: 5.6.30-0+deb8u1

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Datenbank: ``
--

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `addons`
--

CREATE TABLE IF NOT EXISTS `addons` (
`id` int(11) NOT NULL,
  `name` varchar(100) NOT NULL,
  `parameter_1` varchar(100) NOT NULL,
  `parameter_2` varchar(100) NOT NULL,
  `parameter_3` varchar(100) NOT NULL,
  `parameter_4` varchar(100) NOT NULL,
  `box` int(11) NOT NULL,
  `timestamp` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB AUTO_INCREMENT=28 DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `assistent`
--

CREATE TABLE IF NOT EXISTS `assistent` (
`id` int(11) NOT NULL,
  `name` varchar(100) NOT NULL,
  `text` text NOT NULL,
  `from` int(11) NOT NULL,
  `till` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `boxes`
--

CREATE TABLE IF NOT EXISTS `boxes` (
`id` int(11) NOT NULL,
  `name` varchar(80) NOT NULL,
  `alias` varchar(50) NOT NULL,
  `status_light` int(1) NOT NULL DEFAULT '0',
  `status_exhaust` int(4) NOT NULL DEFAULT '0',
  `status_fan` int(4) NOT NULL DEFAULT '0',
  `exhaust_change` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `fan_change` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `notes` text NOT NULL,
  `growmode` varchar(6) NOT NULL DEFAULT 'none',
  `vegi_start` varchar(10) NOT NULL DEFAULT '0',
  `flower_start` varchar(10) NOT NULL DEFAULT '0',
  `humidity_calibration` int(3) NOT NULL DEFAULT '0',
  `temperature_calibration` int(3) NOT NULL DEFAULT '0',
  `soil_calibration` int(3) NOT NULL DEFAULT '0',
  `max_temprature` int(2) NOT NULL DEFAULT '25',
  `max_humidity` int(3) NOT NULL DEFAULT '50',
  `watering_auto` int(1) NOT NULL DEFAULT '0',
  `fan` int(1) NOT NULL DEFAULT '1',
  `exhaust` int(1) NOT NULL DEFAULT '1',
  `light` int(1) NOT NULL DEFAULT '1',
  `light_on` int(2) NOT NULL DEFAULT '18',
  `light_off` int(2) NOT NULL DEFAULT '14',
  `pump_runtime` int(5) NOT NULL DEFAULT '1000',
  `pump_repeats` int(3) NOT NULL DEFAULT '1',
  `pump_repeats_delay` int(4) NOT NULL DEFAULT '200',
  `watering_min_soil` int(3) NOT NULL DEFAULT '360',
  `watering_trys` int(2) NOT NULL DEFAULT '2',
  `fans_change_interval` int(4) NOT NULL DEFAULT '180',
  `fans_step` int(4) NOT NULL DEFAULT '100',
  `fans_speed_max` int(11) NOT NULL DEFAULT '1024',
  `last_seen` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `registered` datetime NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=22 DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `logs_light`
--

CREATE TABLE IF NOT EXISTS `logs_light` (
`id` int(11) NOT NULL,
  `status` int(1) NOT NULL,
  `type` varchar(10) NOT NULL,
  `box` varchar(80) NOT NULL,
  `time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=MyISAM AUTO_INCREMENT=559 DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `logs_pump`
--

CREATE TABLE IF NOT EXISTS `logs_pump` (
`id` int(11) NOT NULL,
  `box` varchar(80) NOT NULL,
  `soil` float NOT NULL,
  `type` varchar(10) NOT NULL,
  `runtime` int(11) NOT NULL,
  `time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB AUTO_INCREMENT=315 DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `logs_sensors`
--

CREATE TABLE IF NOT EXISTS `logs_sensors` (
`id` int(11) NOT NULL,
  `temp` float NOT NULL,
  `humi` float NOT NULL,
  `soil` float NOT NULL,
  `box` varchar(80) NOT NULL,
  `time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB AUTO_INCREMENT=1476570 DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `messages`
--

CREATE TABLE IF NOT EXISTS `messages` (
`id` int(11) NOT NULL,
  `box` varchar(80) NOT NULL,
  `message` varchar(255) NOT NULL,
  `type` varchar(20) NOT NULL,
  `error` int(1) NOT NULL,
  `time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB AUTO_INCREMENT=17751 DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `plans`
--

CREATE TABLE IF NOT EXISTS `plans` (
`id` int(11) NOT NULL,
  `box` int(11) NOT NULL,
  `job` varchar(30) NOT NULL,
  `plan_condition` varchar(30) NOT NULL,
  `value` varchar(30) NOT NULL,
  `plan_interval` int(11) NOT NULL,
  `last_execution` datetime NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `_transmissions`
--

CREATE TABLE IF NOT EXISTS `_transmissions` (
`id` int(11) NOT NULL,
  `sender` varchar(80) NOT NULL,
  `recipient` varchar(80) NOT NULL,
  `data` text NOT NULL,
  `validity_from` datetime NOT NULL,
  `time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB AUTO_INCREMENT=17115 DEFAULT CHARSET=latin1;

--
-- Indizes der exportierten Tabellen
--

--
-- Indizes für die Tabelle `addons`
--
ALTER TABLE `addons`
 ADD PRIMARY KEY (`id`);

--
-- Indizes für die Tabelle `assistent`
--
ALTER TABLE `assistent`
 ADD PRIMARY KEY (`id`);

--
-- Indizes für die Tabelle `boxes`
--
ALTER TABLE `boxes`
 ADD PRIMARY KEY (`id`), ADD UNIQUE KEY `name` (`name`);

--
-- Indizes für die Tabelle `logs_light`
--
ALTER TABLE `logs_light`
 ADD PRIMARY KEY (`id`);

--
-- Indizes für die Tabelle `logs_pump`
--
ALTER TABLE `logs_pump`
 ADD PRIMARY KEY (`id`);

--
-- Indizes für die Tabelle `logs_sensors`
--
ALTER TABLE `logs_sensors`
 ADD PRIMARY KEY (`id`);

--
-- Indizes für die Tabelle `messages`
--
ALTER TABLE `messages`
 ADD PRIMARY KEY (`id`);

--
-- Indizes für die Tabelle `plans`
--
ALTER TABLE `plans`
 ADD PRIMARY KEY (`id`), ADD KEY `id` (`id`);

--
-- Indizes für die Tabelle `_transmissions`
--
ALTER TABLE `_transmissions`
 ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT für exportierte Tabellen
--

--
-- AUTO_INCREMENT für Tabelle `addons`
--
ALTER TABLE `addons`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=28;
--
-- AUTO_INCREMENT für Tabelle `assistent`
--
ALTER TABLE `assistent`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT für Tabelle `boxes`
--
ALTER TABLE `boxes`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=22;
--
-- AUTO_INCREMENT für Tabelle `logs_light`
--
ALTER TABLE `logs_light`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=559;
--
-- AUTO_INCREMENT für Tabelle `logs_pump`
--
ALTER TABLE `logs_pump`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=315;
--
-- AUTO_INCREMENT für Tabelle `logs_sensors`
--
ALTER TABLE `logs_sensors`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=1476570;
--
-- AUTO_INCREMENT für Tabelle `messages`
--
ALTER TABLE `messages`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=17751;
--
-- AUTO_INCREMENT für Tabelle `plans`
--
ALTER TABLE `plans`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT für Tabelle `_transmissions`
--
ALTER TABLE `_transmissions`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=17115;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;