<?php

//date_default_timezone_set('Europe/Berlin');

// MYSQL Logindaten
define("MYSQL_SERVER", "");
define("MYSQL_DB", "");
define("MYSQL_USER", "");
define("MYSQL_PASS", "");

// URL Zur Webseite ohne Slashzeichen am Ende
define("URL", "");  // example http://myname.com
define("PASSWORD", "");
define("MAIL_ADRESS", "");

define("VERSION", "1.0");
?>